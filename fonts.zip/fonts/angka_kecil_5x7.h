

/*
 *
 * angka_kecil_5x9
 *
 * created with FontCreator
 * written by F. Maximilian Thiele
 *
 * http://www.apetech.de/fontCreator
 * me@apetech.de
 *
 * File Name           : angka_kecil_5x9
 * Date                : 04.11.2018
 * Font size in bytes  : 605
 * Font width          : 5
 * Font height         : -9
 * Font first char     : 48
 * Font last char      : 62
 * Font used chars     : 14
 *
 * The font data are defined as
 *
 * struct _FONT_ {
 *     uint16_t   font_Size_in_Bytes_over_all_included_Size_it_self;
 *     uint8_t    font_Width_in_Pixel_for_fixed_drawing;
 *     uint8_t    font_Height_in_Pixel_for_all_characters;
 *     unit8_t    font_First_Char;
 *     uint8_t    font_Char_Count;
 *
 *     uint8_t    font_Char_Widths[font_Last_Char - font_First_Char +1];
 *                  // for each character the separate width in pixels,
 *                  // characters < 128 have an implicit virtual right empty row
 *
 *     uint8_t    font_data[];
 *                  // bit field of all characters
 */

#include <inttypes.h>
#ifdef __AVR__
#include <avr/pgmspace.h>
#elif defined (ESP8266)
#include <pgmspace.h>
#else
#define PROGMEM
#endif

#ifndef ANGKA_KECIL_5X7_H
#define ANGKA_KECIL_5X7_H

#define ANGKA_KECIL_5X7_WIDTH 5
#define ANGKA_KECIL_5X7_HEIGHT 7

static const uint8_t angka_kecil_5x7[] PROGMEM = {
  0x02, 0x1C, // size
    0x05, // width
    0x07, // height
    0x30, // first char
    0x10, // char count
    
    // char widths
    0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 0x05, 
    0x02, 0x02, 0x05, 0x05, 0x05, 0x05, 
    
    // font data
    0x7C, 0xFE, 0x82, 0xFE, 0x7C, // 48
    0x00, 0x04, 0xFE, 0xFE, 0x00, // 49
    0x84, 0xE6, 0xF2, 0x9E, 0x8C, // 50
    0x44, 0xC6, 0x92, 0xFE, 0x6C, // 51
    0x78, 0x64, 0xFE, 0xFE, 0x60, // 52
    0x5E, 0xDE, 0x8A, 0xFA, 0x7A, // 53
    0x7C, 0xFE, 0x92, 0xF6, 0x74, // 54
    0x00, 0x02, 0xC2, 0xFE, 0x1E, // 55
    0x6C, 0xFE, 0x92, 0xFE, 0x6C, // 56
    0x4C, 0xDE, 0x92, 0xFE, 0x7C, // 57
    0x6C, 0x6C, // 58
    0x00, 0x00, // 59
    0x00, 0x10, 0x38, 0x7C, 0xFE, // 60
    0x00, 0x00, 0x00, 0x00, 0x00, // 61
    0xFE, 0x7C, 0x38, 0x10, 0x00, // 62
    0x30, 0x30, 0x30, 0x30, 0x30 // 63
    
};

#endif
